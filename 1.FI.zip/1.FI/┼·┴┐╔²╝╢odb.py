# -*- coding: mbcs -*-
# Do not delete the following import lines
from abaqus import *
from abaqusConstants import *
import __main__


import section
import regionToolset
import displayGroupMdbToolset as dgm
import part
import material
import assembly
import step
import interaction
import load
import mesh
import optimization
import job
import sketch
import visualization
import xyPlot
import displayGroupOdbToolset as dgo
import connectorBehavior
for i in range(0,36):
    o1 = session.openOdb(
        name='Design_Job'+str(i)+'.odb', 
        readOnly=False)
    session.viewports['Viewport: 1'].setValues(displayedObject=o1)
    from  abaqus import session
    session.upgradeOdb(
        'Design_Job'+str(i)+'-old.odb', 
        'Design_Job'+str(i)+'.odb', 
        )
    from  abaqus import session
    o7 = session.openOdb(
        'Design_Job'+str(i)+'.odb', 
        readOnly=False)
    session.viewports['Viewport: 1'].setValues(displayedObject=o7)
    import caeXmlObjects.kernel.mainXML
    caeXmlObjects.kernel.mainXML.loadXMLRecords(
        fileName='Design_Job'+str(i)+'.odb', 
        className='caeXmlObjects.displayGroups.dgXML.DGXML', silentMode=False, 
        outputType='ODB')
    caeXmlObjects.kernel.mainXML.loadXMLRecords(
        fileName='Design_Job'+str(i)+'.odb', 
        className='caeXmlObjects.paths.pathXML.PathXML', silentMode=False, 
        outputType='ODB')
    caeXmlObjects.kernel.mainXML.loadXMLRecords(
        fileName='Design_Job'+str(i)+'.odb', 
        className='caeXmlObjects.xyData.xyDataXML.XYDataXML', silentMode=False, 
        outputType='ODB')
    caeXmlObjects.kernel.mainXML.loadXMLRecords(
        fileName='Design_Job'+str(i)+'.odb', 
        className='caeXmlObjects.viewCuts.viewCutXML.ViewCutXML', 
        silentMode=False, outputType='ODB')
    caeXmlObjects.kernel.mainXML.loadXMLRecords(
        fileName='Design_Job'+str(i)+'.odb', 
        className='caeXmlObjects.freeBodies.fbXML.FBXML', silentMode=False, 
        outputType='ODB')
    caeXmlObjects.kernel.mainXML.loadXMLRecords(
        fileName='Design_Job'+str(i)+'.odb', 
        className='caeXmlObjects.spectrum.spectrumXML.SpectrumXML', 
        silentMode=False, outputType='ODB')
    caeXmlObjects.kernel.mainXML.kernelCommand(
        fileName='Design_Job'+str(i)+'.odb', 
        className='caeXmlObjects.viewerPlotOptions.odbDisplay.odbDisplayXML.OdbDisplayXML', 
        silentMode=False, recordName='ODB Display', outputType='ODB', isSave=0)
    caeXmlObjects.kernel.mainXML.kernelCommand(
        fileName='Design_Job'+str(i)+'.odb', 
        className='caeXmlObjects.viewerPlotOptions.basicOptions.basicOptionsXML.BasicOptionsXML', 
        silentMode=False, recordName='Basic Options', outputType='ODB', 
        isSave=0)
    caeXmlObjects.kernel.mainXML.kernelCommand(
        fileName='Design_Job'+str(i)+'.odb', 
        className='caeXmlObjects.customViews.customViewsXML.CustomViewsXML', 
        silentMode=False, recordName='Custom Views', outputType='ODB', 
        isSave=0)
    caeXmlObjects.kernel.mainXML.kernelCommand(
        fileName='Design_Job'+str(i)+'.odb', 
        className='caeXmlObjects.views.ViewsXML.ViewsXML', silentMode=False, 
        recordName='Views', outputType='ODB', isSave=0)
    caeXmlObjects.kernel.mainXML.kernelCommand(
        fileName='Design_Job'+str(i)+'.odb', 
        className='caeXmlObjects.viewerPlotOptions.commonOptions.commonOptionsXML.CommonOptionsXML', 
        silentMode=False, recordName='Common Options', outputType='ODB', 
        isSave=0)
    caeXmlObjects.kernel.mainXML.kernelCommand(
        fileName='Design_Job'+str(i)+'.odb', 
        className='caeXmlObjects.viewerPlotOptions.contourOptions.contourOptionsXML.ContourOptionsXML', 
        silentMode=False, recordName='Contour Options', outputType='ODB', 
        isSave=0)
    caeXmlObjects.kernel.mainXML.kernelCommand(
        fileName='Design_Job'+str(i)+'.odb', 
        className='caeXmlObjects.viewerPlotOptions.superimposeOptions.superimposeOptionsXML.SuperimposeOptionsXML', 
        silentMode=False, recordName='Superimpose Options', outputType='ODB', 
        isSave=0)
    caeXmlObjects.kernel.mainXML.kernelCommand(
        fileName='Design_Job'+str(i)+'.odb', 
        className='caeXmlObjects.viewerPlotOptions.materialOrientationOptions.materialOrientationOptionsXML.MaterialOrientationOptionsXML', 
        silentMode=False, recordName='Material Orientation Options', 
        outputType='ODB', isSave=0)
    caeXmlObjects.kernel.mainXML.kernelCommand(
        fileName='Design_Job'+str(i)+'.odb', 
        className='caeXmlObjects.viewerPlotOptions.plyStackPlotOptions.plyStackPlotOptionsXML.PlyStackPlotOptionsXML', 
        silentMode=False, recordName='Ply Stack Plot Options', 
        outputType='ODB', isSave=0)
    caeXmlObjects.kernel.mainXML.kernelCommand(
        fileName='Design_Job'+str(i)+'.odb', 
        className='caeXmlObjects.viewerPlotOptions.symbolOptions.symbolOptionsXML.SymbolOptionsXML', 
        silentMode=False, recordName='Symbol Options', outputType='ODB', 
        isSave=0)
    caeXmlObjects.kernel.mainXML.kernelCommand(
        fileName='Design_Job'+str(i)+'.odb', 
        className='caeXmlObjects.viewerPlotOptions.freeBodyOptions.freeBodyOptionsXML.FreeBodyOptionsXML', 
        silentMode=False, recordName='Free Body Options', outputType='ODB', 
        isSave=0)
    caeXmlObjects.kernel.mainXML.kernelCommand(
        fileName='Design_Job'+str(i)+'.odb', 
        className='caeXmlObjects.viewerPlotOptions.viewCutOptions.viewCutOptionsXML.ViewCutOptionsXML', 
        silentMode=False, recordName='View Cut Options', outputType='ODB', 
        isSave=0)
    caeXmlObjects.kernel.mainXML.kernelCommand(
        fileName='Design_Job'+str(i)+'.odb', 
        className='caeXmlObjects.viewerPlotOptions.xPlane.xPlaneXML.XPlaneXML', 
        silentMode=False, recordName='X Plane', outputType='ODB', isSave=0)
    caeXmlObjects.kernel.mainXML.kernelCommand(
        fileName='Design_Job'+str(i)+'.odb', 
        className='caeXmlObjects.viewerPlotOptions.yPlane.yPlaneXML.YPlaneXML', 
        silentMode=False, recordName='Y Plane', outputType='ODB', isSave=0)
    caeXmlObjects.kernel.mainXML.kernelCommand(
        fileName='Design_Job'+str(i)+'.odb', 
        className='caeXmlObjects.viewerPlotOptions.zPlane.zPlaneXML.ZPlaneXML', 
        silentMode=False, recordName='Z Plane', outputType='ODB', isSave=0)