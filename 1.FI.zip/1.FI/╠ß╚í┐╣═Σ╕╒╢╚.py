# -*- coding: mbcs -*-
# Do not delete the following import lines
from abaqus import *
from abaqusConstants import *
import __main__
import section
import regionToolset
import displayGroupMdbToolset as dgm
import part
import material
import assembly
import step
import interaction
import load
import mesh
import optimization
import job
import sketch
import visualization
import xyPlot
import displayGroupOdbToolset as dgo
import connectorBehavior

K_B=[]
for i in range(0,36):
    session.Viewport(name='Viewport: 1', origin=(0.0, 0.0), width=164.836547851562, 
        height=154.339706420898)
    session.viewports['Viewport: 1'].makeCurrent()
    session.viewports['Viewport: 1'].maximize()
    from caeModules import *
    from driverUtils import executeOnCaeStartup
    executeOnCaeStartup()
    session.viewports['Viewport: 1'].partDisplay.geometryOptions.setValues(
        referenceRepresentation=ON)
    import os
    os.chdir(r"G:\2023_9_5_RightCorner_CTSH_Topo_smallElements\2023_11_27_����ʦ�¹���վ\2023_10_02_Jinhao\1.FI")
    o1 = session.openOdb(
        name='Design_Job'+str(i)+'.odb', 
        readOnly=False)
    session.viewports['Viewport: 1'].setValues(displayedObject=o1)

    odb = session.odbs['Design_Job'+str(i)+'.odb']
    xyList = xyPlot.xyDataListFromField(odb=odb, outputPosition=NODAL, variable=((
        'RM', NODAL, ((COMPONENT, 'RM1'), )), ('UR', NODAL, ((COMPONENT, 'UR1'), 
        )), ), nodeSets=("RP_CENTER", ))
    xyp = session.XYPlot('XYPlot-'+str(i))
    chartName = xyp.charts.keys()[0]
    chart = xyp.charts[chartName]
    curveList = session.curveSet(xyData=xyList)
    chart.setValues(curvesToPlot=curveList)
    session.charts[chartName].autoColor(lines=True, symbols=True)
    session.viewports['Viewport: 1'].setValues(displayedObject=xyp)
    xy1 = session.xyDataObjects['_UR:UR1 PI: RP_CENTER-1 N: 1']
    xy2 = session.xyDataObjects['_RM:RM1 PI: RP_CENTER-1 N: 1']
    xy3 = combine(xy1, xy2)
    xyp = session.xyPlots['XYPlot-'+str(i)]
    chartName = xyp.charts.keys()[0]
    chart = xyp.charts[chartName]
    c1 = session.Curve(xyData=xy3)
    chart.setValues(curvesToPlot=(c1, ), )
    session.charts[chartName].autoColor(lines=True, symbols=True)
    x0 = session.xyDataObjects['_temp_1']
    session.writeXYReport(fileName='KB.txt', xyData=(x0, ))
    del session.xyDataObjects['_temp_1']
    session.odbs['Design_Job'+str(i)+'.odb'].close()

    # ���ú����������ļ�·��
    file_path = 'KB.txt'
    x_values = []
    kb_values = []

    with open(file_path, 'r') as file:
        for line in file:
            stripped_line = line.strip()
            if stripped_line:
                try:
                    # �ָ�ÿ�е�����
                    x, kb = stripped_line.split()
                    # ���ַ�������ת��Ϊ�������������ӵ���Ӧ���б���
                    x_values.append(float(x))
                    kb_values.append(float(kb))
                except ValueError:
                    # ������ݲ��Ǹ�������������һ��
                    continue
    os.remove(file_path)          
    del session.xyDataObjects['KB']
    K_B.append(kb_values[1]/x_values[1]/57.29)
###==============================================================
# ָ������ļ���·��
output_file_path = 'K_B.txt'

# ���ļ���д������
with open(output_file_path, 'w') as file:
    for number in K_B:
        file.write("{}\n".format(number))

