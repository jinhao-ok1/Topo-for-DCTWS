#! /user/bin/python
#-*-coding: UTF-8-*-
# -*- coding: mbcs -*-
# Do not delete the following import lines
from abaqus import *
from abaqusConstants import *
import __main__
from part import *
from material import *
from section import *
from assembly import *
from step import *
from interaction import *
from load import *
from mesh import *
from optimization import *
from job import *
from sketch import *
from visualization import *
from connectorBehavior import *
from odbAccess import*
from textRepr import prettyPrint
from numpy import linalg
import time
from os.path import exists
import math,customKernel
from abaqus import getInput,getInputs
from odbAccess import openOdb
import xyPlot
import regionToolset
import displayGroupOdbToolset as dgo
import displayGroupMdbToolset as dgm
import sys, os, glob
import numpy as np
import numpy
def FEA_FI(Iter,Mdb,Xe,Ae_FI,Ae1,Ae1_2,Ae1_3,Ae2,Ae5):


    mdb.Job(name='Design_Job'+str(Iter), model='Model-iter-'+str(Iter), description='', type=ANALYSIS, 
        atTime=None, waitMinutes=0, waitHours=0, queue=None, memory=90, 
        memoryUnits=PERCENTAGE, getMemoryFromAnalysis=True, 
        explicitPrecision=SINGLE, nodalOutputPrecision=SINGLE, echoPrint=OFF, 
        modelPrint=OFF, contactPrint=OFF, historyPrint=OFF, userSubroutine='', 
        scratch='', resultsFormat=ODB, multiprocessingMode=MPI, numCpus=10, 
        numDomains=10, numGPUs=1)
    mdb.jobs['Design_Job'+str(Iter)].submit(consistencyChecking=OFF)
    mdb.jobs['Design_Job'+str(Iter)].waitForCompletion()
    
    mdb.Job(name='Design_Job_Buckling'+str(Iter), model='Model-iter-buckling-'+str(Iter), description='', type=ANALYSIS, 
        atTime=None, waitMinutes=0, waitHours=0, queue=None, memory=90, 
        memoryUnits=PERCENTAGE, getMemoryFromAnalysis=True, 
        explicitPrecision=SINGLE, nodalOutputPrecision=SINGLE, echoPrint=OFF, 
        modelPrint=OFF, contactPrint=OFF, historyPrint=OFF, userSubroutine='', 
        scratch='', resultsFormat=ODB, multiprocessingMode=DEFAULT, numCpus=1, 
        numGPUs=0)
    mdb.jobs['Design_Job_Buckling'+str(Iter)].submit(consistencyChecking=OFF)    
    mdb.jobs['Design_Job_Buckling'+str(Iter)].waitForCompletion()    
    
    
    # Faiulre strength parameters
    #-----------------------------------------------------------
    sF1t = 76.16
    sF1c = 34.50
    sF3 = 14.55
    sF4 = 3.26
    sF6 = 1.10

    # calculating failure coefficients
    #---------------------------------
    sJ1 = 1/sF1t - 1/sF1c
    sK11 = 1/(sF1t*sF1c)
    sK33 = 1/pow(sF3,2)
    sK44 = 1/pow(sF4,2)
    sK66 = 1/pow(sF6,2)
    sK12 = -sK11/2
    #------------------------------------------------------------------------------
    #---------------------Initialize Global Variables------------------------------
    #------------------------------------------------------------------------------ 
    odb = None
    instance = None
    odbName = None
    allSteps = False# consider all steps or single step
    allFrames = False# consider all frames or only final frame
    debug = False

    #----------------------------------------------------------
    # User input: odb data
    #----------------------------------------------------------
    odbPath = 'Design_Job'+str(Iter)+'.odb'
    stepName = 'Step-1'
    #stepNames = ['folding','deployment']
    stepNames = ['Step-1']
    instanceName = 'PART-1-1'


    #==========================================================================
    # S T A R T
    #========================================================================== 
    o1 = session.openOdb(name= odbPath, readOnly=0)
    odb = session.odbs[odbPath]
    odbName = odb.name

    assembly = odb.rootAssembly
    instance = assembly.instances[instanceName]
      

    for sName in stepNames:
        step = odb.steps[sName]
        fCount = 0
        frame = step.frames[-1]
        global dataFI   
        # containters for element labels and stress-resultants
        labels = []
        dataF = []
        dataM = []
        dataFI = []
        # create reference to append fuctions
        labelsAppend = labels.append
        dataFAppend = dataF.append
        dataMAppend = dataM.append
        dataFIAppend = dataFI.append
        lastLabel = -1
        fieldType = VECTOR

        #take field output SF and SM only from 2-ply sets
        force = frame.fieldOutputs['SF']
        moment = frame.fieldOutputs['SM']
        twoply = odb.rootAssembly.instances[instanceName].elementSets['SET-OPTDOMAIN']
        #twoply = odb.rootAssembly.instances[instanceName]
        force_subset_twoply = force.getSubset(region=twoply)
        moment_subset_twoply = moment.getSubset(region=twoply)

        fValues = force_subset_twoply.values#set�е����е�Ԫ
        mValues = moment_subset_twoply.values#set�е����е�Ԫ
        #�����е�Ԫ�н���ѭ��
        for i in range (len(fValues)):

            fValue = fValues[i]
            mValue = mValues[i]
            
            label = fValue.elementLabel
            if lastLabel != label:
                labelsAppend(label)
            lastLabel = label

            M1, M2, M12 = mValue.data
            N1, N2, N3, N12, N13, N23 = fValue.data
        

        
            Nx = 0.5*(N1 + N2) + N12
            Ny = 0.5*(N1 + N2) - N12
            Nxy = 0.5*(N2 - N1)
            
            Mx = 0.5*(M1 + M2) + M12
            My = 0.5*(M1 + M2) - M12
            Mxy = 0.5*(M2 - M1)

            dataValueM = (Mx, My, Mxy)
            dataValueF = (Nx, Ny, Nxy)

    #-----------------------        
    #       In-plane loads
    #-----------------------
            fIndexIP = sJ1*(Nx+Ny) + sK11*( pow(Nx,2)+ pow(Ny,2) ) + sK12*Nx*Ny + sK33*pow(Nxy,2)
        
    #-----------------------
    #       Moments
    #-----------------------
            if (abs(Mx) >= abs(My)):
                M = Mx
            else:
                M = My
            
            fIndexM = sK44*pow(M,2) + sK66*pow(Mxy,2)

    #-----------------------
    #       Interaction
    #-----------------------
            fIndexC = 0
            fIndexCx = 0
            fIndexCy = 0
        
            if (fIndexIP >= 1):
                fIndexC = 1
            
            else:
                # Calculating axial strengths 
                
                # Calculating sFx
                sFx = 0.0001            
                delta = pow((sJ1 + sK12*Ny),2) - 4*sK11*(sJ1*Ny + sK11*pow(Ny,2)+ sK33*pow(Nxy,2)-1)
                
                if delta < 0:
                    if debug:
                            print 'Value error, deltaX, b^2-4ac = %s'%delta
                elif Ny >= 0:
                    sFx = (-(sJ1 + sK12*Ny) + sqrt(delta))/(2*sK11)
                else:
                    sFx = (-(sJ1 + sK12*Ny) - sqrt(delta))/(2*sK11)        
                
                fIndexCx = Nx/sFx + abs(M)/sF4

                # Calculating sFy
                sFy = 0.0001
                delta = pow((sJ1 + sK12*Nx),2) - 4*sK11*(sJ1*Nx + sK11*pow(Nx,2)+ sK33*pow(Nxy,2)-1)
                
                if delta < 0:
                    if debug:
                            print 'Value error deltaY, b^2-4ac = %s'%delta
                elif Nx >= 0:
                    sFy = (-(sJ1 + sK12*Nx) + sqrt(delta))/(2*sK11)
                else:
                    sFy = (-(sJ1 + sK12*Nx) - sqrt(delta))/(2*sK11)        
                
                fIndexCy = Ny/sFy + abs(M)/sF4
                
               # selecting maximum index
            
                if (fIndexCx >= fIndexCy):
                    fIndexC = fIndexCx 
                else:
                    fIndexC = fIndexCy
                            
            dataValueFI = (abs(fIndexIP), abs(fIndexM), abs(fIndexC))
        
            dataFAppend(dataValueF)
            dataMAppend(dataValueM)
            dataFIAppend(dataValueFI)

        labels = np.array(labels)
        dataF = np.array(dataF)
        dataM = np.array(dataM)
        dataFI = np.array(dataFI)

        if debug:
            print 'len (labels):%s, len(dataF):%s'%(len(labels), len(dataF))
        se = 'FI'
        componentLabels = ['FI_M-1', 'FI_M-2', 'FI_M-3']
        descript = 'Failure Indices'

        fo = frame.FieldOutput(name=se, 
            description=descript, 
            type=fieldType, 
            componentLabels=componentLabels)

        fo.addData(position=INTEGRATION_POINT, 
            instance=instance, 
            labels=labels, 
            data=dataFI) 
        if debug:
            fCount+=1
            print 'Frame No.%s is added'%fCount
    odb.save()
    session.odbs[odbName].close()
    opdb = openOdb('Design_Job'+str(Iter)+'.odb')
    opdb_buck = openOdb('Design_Job_Buckling'+str(Iter)+'.odb')
    seng = opdb.steps['Step-1'].frames[-1].fieldOutputs['FI'].getSubset(region=opdb.rootAssembly.instances['PART-1-1'].elementSets['SET-OPTDOMAIN']).values
    seng1 = opdb.steps['Step-1'].frames[-1].fieldOutputs['ELSE'].getSubset(region=opdb.rootAssembly.instances['PART-1-1'].elementSets['SET-OPTDOMAIN']).values
    seng_buck = opdb_buck.steps['Step-1'].frames[1].fieldOutputs['ELSE'].getSubset(region=opdb_buck.rootAssembly.instances['PART-1-1'].elementSets['SET-OPTDOMAIN']).values
    Lambda = float(opdb_buck.getFrame(1).description.split("=")[-1])    

    w1 = 0.9 #FI1
    w2 = 0 #FI2
    w3 = 0 #FI3
    w4 = 0 #Stiffness
    w5 = 0.1 #Buckling
    P = 6.0
    q = 3.0
    q_b = 3.0


    for en in seng: 
        Ae1[en.elementLabel] = round(en.data[0],20)
        Ae1_2[en.elementLabel] = round(en.data[1],20)
        Ae1_3[en.elementLabel] = round(en.data[2],20)
        
    Ae1_record,Ae1_2_record,Ae1_3_record = {},{},{}    
    for en in seng: 
        Ae1_record[en.elementLabel] = round(en.data[0],20)
        Ae1_2_record[en.elementLabel] = round(en.data[1],20)
        Ae1_3_record[en.elementLabel] = round(en.data[2],20)
        
    MaxFI = max(max(Ae1_record.values()),max(Ae1_2_record.values()),max(Ae1_3_record.values()))
    MaxFI_1 = max(Ae1_record.values())
    MaxFI_2 = max(Ae1_2_record.values())
    MaxFI_3 = max(Ae1_3_record.values())

    Ae11 = Ae1.values(); Ae11_2 = Ae1_2.values(); Ae11_3 = Ae1_3.values()
    
    Sum_Ae1 = 0; Sum_Ae1_2 = 0; Sum_Ae1_3 = 0
    for i in Ae11 : Sum_Ae1 += i ** P
    for i in Ae11_2 : Sum_Ae1_2 += i ** P
    for i in Ae11_3 : Sum_Ae1_3 += i ** P
        
    for en in seng: 
        Ae1[en.elementLabel] = (q * Xe[en.elementLabel] ** (q-1)) * (Sum_Ae1**(1/P-1)) * Ae1[en.elementLabel] ** (P**2 - P + 1)
        Ae1_2[en.elementLabel] = (q * Xe[en.elementLabel] ** (q-1)) * (Sum_Ae1_2**(1/P-1)) * Ae1_2[en.elementLabel] ** (P**2 - P + 1)
        Ae1_3[en.elementLabel] = (q * Xe[en.elementLabel] ** (q-1)) * (Sum_Ae1_3**(1/P-1)) * Ae1_3[en.elementLabel] ** (P**2 - P + 1)
    for key in Xe.keys():
        Ae1[key] = 1.0 + 2.0 * (Ae1[key] - min(Ae1.values()))/(max(Ae1.values())- min(Ae1.values()))
        Ae1_2[key] = 1.0 + 2.0 * (Ae1_2[key] - min(Ae1_2.values()))/(max(Ae1_2.values())- min(Ae1_2.values()))
        Ae1_3[key] = 1.0 + 2.0 * (Ae1_3[key] - min(Ae1_3.values()))/(max(Ae1_3.values())- min(Ae1_3.values()))
		
    for en in seng1:
        Ae2[en.elementLabel] = -1.0 * q * en.data / Xe[en.elementLabel]
    for key in Xe.keys():
        Ae2[key] = 1.0 + 2.0 * (Ae2[key] - min(Ae2.values()))/(max(Ae2.values())- min(Ae2.values()))
    # Buckling
    for en in seng_buck: 
        Ae5[en.elementLabel] = -1.0 * en.data*(1+abs(Lambda))* q_b /(Xe[en.elementLabel])
    for key in Xe.keys():
        Ae5[key] = 1.0 + 2.0 * (Ae5[key] - min(Ae5.values()))/(max(Ae5.values())- min(Ae5.values()))         
    
    for key in Xe.keys():
        Ae_FI[key] = round(w1 * Ae1[key] + w2 * Ae1_2[key] + w3 * Ae1_3[key] + w4 * Ae2[key] + w5 * Ae5[key],20)

    
    obj=opdb.steps['Step-1'].historyRegions['Assembly ASSEMBLY'].historyOutputs['ALLWK'].data[-1][1]
    #obj_FI = 1.0 * MaxFI
    obj_FI = 1.0 * MaxFI_1
    obj_buck = Lambda 
    obj_FI1 = 1.0 * MaxFI_1
    obj_FI2 = 1.0 * MaxFI_2
    obj_FI3 = 1.0 * MaxFI_3
    maxAe1 = 8.83154
    minAe1 = 0.7940
    maxAe1_2 = 3.39777
    minAe1_2 = 0.9382
    maxAe1_3 = 2.1111
    minAe1_3 = 0.9377
    maxAe2 = 96.5842
    minAe2 = 94.2955
    maxAe5 = 143.87
    minAe5 = 126.65
    Total_Objectiv = w1 * (obj_FI1-minAe1)/(maxAe1-minAe1) + w2 * (obj_FI2-minAe1_2)/(maxAe1_2-minAe1_2) + w3 * (obj_FI3-minAe1_3)/(maxAe1_3-minAe1_3) + w4 * (obj-minAe2)/(maxAe2-minAe2) + w5 * (obj_buck-minAe5)/(maxAe5-minAe5)
    opdb.close()
    opdb_buck.close()
    return obj_FI,obj,obj_buck,obj_FI1,obj_FI2,obj_FI3,Total_Objectiv