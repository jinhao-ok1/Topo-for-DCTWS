#! /user/bin/python
#-*-coding: UTF-8-*-
# -*- coding: mbcs -*-
# Do not delete the following import lines
from abaqus import *
from abaqusConstants import *
import __main__
from part import *
from material import *
from section import *
from assembly import *
from step import *
from interaction import *
from load import *
from mesh import *
from optimization import *
from job import *
from sketch import *
from visualization import *
from connectorBehavior import *
from odbAccess import*
from textRepr import prettyPrint
from numpy import linalg
import time
from os.path import exists
import math,customKernel
from abaqus import getInput,getInputs
from odbAccess import openOdb
import xyPlot
import regionToolset
import displayGroupOdbToolset as dgo
import displayGroupMdbToolset as dgm
import sys, os, glob
import numpy as np
import numpy
def fmtMdb(Mdb):

    mdl = Mdb.models['Model-1']
    mdl2 = Mdb.models['Model-2']
    part = mdl.parts['Part-1']
    part2 = mdl2.parts['Part-1']
    
    mdl.GeneralStiffnessSection(name='sldSec-2ply', referenceTemperature=None, stiffnessMatrix=(3477.1, 1923.1, 3477.1, 0.0, 0.0, 2118, 0.0, 0.0, 0.0, 3.09537, 0.0, 0.0, 0.0, 1.71087, 3.09537, 0.0, 0.0, 0.0, 0.0, 0.0, 1.87778), applyThermalStress=0, poissonDefinition=DEFAULT, useDensity=ON, density=2.1e-10)
    mdl.GeneralStiffnessSection(name='sldSec-3ply', referenceTemperature=None, stiffnessMatrix=(5640, 2121.9, 5640.9, 0.0, 0.0, 2402.1, 0.0, 0.0, 0.0, 10.0013, 0.0, 0.0, 0.0, 5.31263, 10.0013, 0.0, 0.0, 0.0, 0.0, 0.0, 5.86543), applyThermalStress=0, poissonDefinition=DEFAULT, useDensity=ON, density=3.2e-10)
    mdl.GeneralStiffnessSection(name='sldSec-4ply', referenceTemperature=None, stiffnessMatrix=(6085, 3365.4, 6085, 0.0, 0.0, 3706.5, 0.0, 0.0, 0.0, 23.0122, 0.0, 0.0, 0.0, 12.7273, 23.0122, 0.0, 0.0, 0.0, 0.0, 0.0, 14.0174), applyThermalStress=0, poissonDefinition=DEFAULT, useDensity=ON, density=4.15e-10)
    mdl.GeneralStiffnessSection(name='sldSec-6ply', referenceTemperature=None, stiffnessMatrix=(9565.1, 3598, 9565.1, 0.0, 0.0, 4073.1, 0.0, 0.0, 0.0, 69.7918, 0.0, 0.0, 0.0, 37.073, 69.7918, 0.0, 0.0, 0.0, 0.0, 0.0, 40.9306), applyThermalStress=0, poissonDefinition=DEFAULT, useDensity=ON, density=6.1e-10)
    
    mdl.Material('Material02').Elastic(((0.001**3, 0.33),))
    mdl.HomogeneousShellSection(name='voidSec',preIntegrate=OFF, material='Material02', thicknessType=UNIFORM, thickness=0.22, thicknessField='', nodalThicknessField='', idealization=NO_IDEALIZATION, poissonDefinition=DEFAULT, thicknessModulus=None, temperature=GRADIENT, useDensity=OFF, integrationRule=SIMPSON, numIntPts=5)    
    
    mdl2.GeneralStiffnessSection(name='sldSec-2ply', referenceTemperature=None, stiffnessMatrix=(3477.1, 1923.1, 3477.1, 0.0, 0.0, 2118, 0.0, 0.0, 0.0, 3.09537, 0.0, 0.0, 0.0, 1.71087, 3.09537, 0.0, 0.0, 0.0, 0.0, 0.0, 1.87778), applyThermalStress=0, poissonDefinition=DEFAULT, useDensity=ON, density=2.1e-10)
    mdl2.GeneralStiffnessSection(name='sldSec-3ply', referenceTemperature=None, stiffnessMatrix=(5640, 2121.9, 5640.9, 0.0, 0.0, 2402.1, 0.0, 0.0, 0.0, 10.0013, 0.0, 0.0, 0.0, 5.31263, 10.0013, 0.0, 0.0, 0.0, 0.0, 0.0, 5.86543), applyThermalStress=0, poissonDefinition=DEFAULT, useDensity=ON, density=3.2e-10)
    mdl2.GeneralStiffnessSection(name='sldSec-4ply', referenceTemperature=None, stiffnessMatrix=(6085, 3365.4, 6085, 0.0, 0.0, 3706.5, 0.0, 0.0, 0.0, 23.0122, 0.0, 0.0, 0.0, 12.7273, 23.0122, 0.0, 0.0, 0.0, 0.0, 0.0, 14.0174), applyThermalStress=0, poissonDefinition=DEFAULT, useDensity=ON, density=4.15e-10)
    mdl2.GeneralStiffnessSection(name='sldSec-6ply', referenceTemperature=None, stiffnessMatrix=(9565.1, 3598, 9565.1, 0.0, 0.0, 4073.1, 0.0, 0.0, 0.0, 69.7918, 0.0, 0.0, 0.0, 37.073, 69.7918, 0.0, 0.0, 0.0, 0.0, 0.0, 40.9306), applyThermalStress=0, poissonDefinition=DEFAULT, useDensity=ON, density=6.1e-10)
    
    mdl2.Material('Material02').Elastic(((0.001**3, 0.33),))
    mdl2.HomogeneousShellSection(name='voidSec',preIntegrate=OFF, material='Material02', thicknessType=UNIFORM, thickness=0.22, thicknessField='', nodalThicknessField='', idealization=NO_IDEALIZATION, poissonDefinition=DEFAULT, thicknessModulus=None, temperature=GRADIENT, useDensity=OFF, integrationRule=SIMPSON, numIntPts=5)    
