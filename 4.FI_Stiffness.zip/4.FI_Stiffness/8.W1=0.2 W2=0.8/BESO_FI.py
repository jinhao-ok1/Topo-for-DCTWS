#! /user/bin/python
#-*-coding: UTF-8-*-
# -*- coding: mbcs -*-
# Do not delete the following import lines
from abaqus import *
from abaqusConstants import *
import __main__
from part import *
from material import *
from section import *
from assembly import *
from step import *
from interaction import *
from load import *
from mesh import *
from optimization import *
from job import *
from sketch import *
from visualization import *
from connectorBehavior import *
from odbAccess import*
from textRepr import prettyPrint
from numpy import linalg
import time
from os.path import exists
import math,customKernel
from abaqus import getInput,getInputs
from odbAccess import openOdb
import xyPlot
import regionToolset
import displayGroupOdbToolset as dgo
import displayGroupMdbToolset as dgm
import sys, os, glob
import numpy as np
import numpy
def BESO_FI(Vf,Xe,Ae_FI,Part,Part2,Elmts,C0,C1):
    lo, hi = min(Ae_FI.values()), max(Ae_FI.values())
    tv = Vf*Element_Totalnumber_initial
    while abs((hi-lo)/hi) > 1.0e-5 :
        th = (lo+hi)/2.0
        for key in Xe.keys():
            if key in Opt_domain:
                Xe[key] = 1.0 if Ae_FI[key] < th else 0.001
        if sum(Xe.values())-tv > 0: hi = th
        else: lo = th
    # Label elements as solid or void
    for el1 in Elmts :
        if el1.label in Opt_domain:
            if Xe[el1.label] == 1.0:
                if el1.label in two_ply: slb_FI_2ply.append(el1.label)
                if el1.label in three_ply: slb_FI_3ply.append(el1.label)
                if el1.label in four_ply: slb_FI_4ply.append(el1.label)
                if el1.label in six_ply: slb_FI_6ply.append(el1.label)
            if Xe[el1.label] != 1.0:
                vlb_FI.append(el1.label)
    if len(slb_FI_2ply)!=0:       
        Part.SectionAssignment(Part.SetFromElementLabels('SS_FI_2PLY',slb_FI_2ply),'sldSec-2ply')
        Part2.SectionAssignment(Part2.SetFromElementLabels('SS_FI_2PLY',slb_FI_2ply),'sldSec-2ply')
    if len(slb_FI_3ply)!=0:
        Part.SectionAssignment(Part.SetFromElementLabels('SS_FI_3PLY',slb_FI_3ply),'sldSec-3ply')
        Part2.SectionAssignment(Part2.SetFromElementLabels('SS_FI_3PLY',slb_FI_3ply),'sldSec-3ply')
    if len(slb_FI_4ply)!=0: 
        Part.SectionAssignment(Part.SetFromElementLabels('SS_FI_4PLY',slb_FI_4ply),'sldSec-4ply')
        Part2.SectionAssignment(Part2.SetFromElementLabels('SS_FI_4PLY',slb_FI_4ply),'sldSec-4ply')
    if len(slb_FI_6ply)!=0:
        Part.SectionAssignment(Part.SetFromElementLabels('SS_FI_6PLY',slb_FI_6ply),'sldSec-6ply')
        Part2.SectionAssignment(Part2.SetFromElementLabels('SS_FI_6PLY',slb_FI_6ply),'sldSec-6ply')
    if len(vlb_FI)!=0:
        Part.SectionAssignment(Part.SetFromElementLabels('VS_FI',vlb_FI),'voidSec')
        Part2.SectionAssignment(Part2.SetFromElementLabels('VS_FI',vlb_FI),'voidSec')