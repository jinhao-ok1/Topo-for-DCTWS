#! /user/bin/python
#-*-coding: UTF-8-*-
# -*- coding: mbcs -*-
# Do not delete the following import lines
from abaqus import *
from abaqusConstants import *
import __main__
from part import *
from material import *
from section import *
from assembly import *
from step import *
from interaction import *
from load import *
from mesh import *
from optimization import *
from job import *
from sketch import *
from visualization import *
from connectorBehavior import *
from odbAccess import*
from textRepr import prettyPrint
from numpy import linalg
import time
from os.path import exists
import math,customKernel
from abaqus import getInput,getInputs
from odbAccess import openOdb
import xyPlot
import regionToolset
import displayGroupOdbToolset as dgo
import displayGroupMdbToolset as dgm
import sys, os, glob
import numpy as np
import numpy
def fltAe_FI(Ae_FI,Fm):
    raw = Ae_FI.copy()
    for el in Fm.keys():
        Ae_FI[el] = 0.0
        for i in range(len(Fm[el][0])): Ae_FI[el]+=raw[Fm[el][0][i]]*Fm[el][1][i]