#! /user/bin/python
#-*-coding: UTF-8-*-
# -*- coding: mbcs -*-
# Do not delete the following import lines
from abaqus import *
from abaqusConstants import *
import __main__
from part import *
from material import *
from section import *
from assembly import *
from step import *
from interaction import *
from load import *
from mesh import *
from optimization import *
from job import *
from sketch import *
from visualization import *
from connectorBehavior import *
from odbAccess import*
from textRepr import prettyPrint
from numpy import linalg
import time
from os.path import exists
import math,customKernel
from abaqus import getInput,getInputs
from odbAccess import openOdb
import xyPlot
import regionToolset
import displayGroupOdbToolset as dgo
import displayGroupMdbToolset as dgm
import sys, os, glob
import numpy as np
import numpy
execfile('FEA_FI.py')
execfile('BESO_FI.py')
execfile('fltAe_FI.py')
execfile('fmtMdb.py')
execfile('preFlt.py')
## ====== MAIN PROGRAM ======
if __name__ == '__main__':
    # Set parameters and inputs
    pars = (('VolFrac:','0.5'), ('Rmin:', '1'), ('ER:', '0.02'))
    vf,rmin,ert = [float(k) if k!=None else 0 for k in getInputs(pars,dialogTitle='Parameters')]
    if vf<=0 or rmin<0 or ert<=0: sys.exit()
    mddb = openMdb(getInput('Input CAE file:',default='Test.cae'))
    # Design initialization
    fmtMdb(mddb)
    part = mddb.models['Model-1'].parts['Part-1']
    part2 = mddb.models['Model-2'].parts['Part-1']
    elmts, nds = part.sets['SET-OPTDOMAIN'].elements, part.nodes
    
    #Initial element number
    Element_Totalnumber_initial = len(elmts)
    
    elmts2 = part.sets['SET-OPTDOMAIN'].elements
    
    Opt_domain=[]
    for el_fix in elmts2:
        Opt_domain.append(el_fix.label)
        
    two_ply , three_ply, four_ply, six_ply = [], [], [], []
    for el in part.sets['TWO_PLIES'].elements: two_ply.append(el.label)
    for el in part.sets['THREE_PLIES'].elements: three_ply.append(el.label)
    for el in part.sets['FOUR_PLIES'].elements: four_ply.append(el.label)
    for el in part.sets['SIX_PLIES'].elements: six_ply.append(el.label)
    
    slb_FI_2ply,slb_FI_3ply,slb_FI_4ply,slb_FI_6ply,vlb_FI,vlb,slb = [],[],[],[],[],[],[]
    oh, vh , oh_buck= [], [], []
    oh_FI, oh_FI_1, oh_FI_2, oh_FI_3, oh_total =[],[],[],[], []
    c0, c1 = {}, {}
    xe, ae, ae_FI, oae, oae_FI, fm , ae1, ae1_2, ae1_3, ae2, ae5 = {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}
    dif_A,dif_B,dif_C = {},{},{}
    for el in elmts: xe[el.label] = 1.0

    if rmin>0: preFlt(rmin,elmts,nds,fm)
    # Optimization iteration
    change, iter, obj, nv = 1, -1, 0, 1
    
    executed = False
    #while nv > vf :
    while abs(change) > 0.01 or nv > vf or oh_FI[-1] > 1: 
        iter += 1
        # Run FEA
        mddb.Model(name='Model-iter-'+str(iter), objectToCopy=mdb.models['Model-1'])
        if str('VS_FI') in mddb.models['Model-iter-'+str(iter)].parts['Part-1'].sets.keys():
            mddb.models['Model-iter-'+str(iter)].parts['Part-1'].deleteElement(elements = mddb.models['Model-iter-'+str(iter)].parts['Part-1'].sets['VS_FI'])
        mddb.Model(name='Model-iter-buckling-'+str(iter), objectToCopy=mdb.models['Model-2'])
        if str('VS_FI') in mddb.models['Model-iter-buckling-'+str(iter)].parts['Part-1'].sets.keys():
            mddb.models['Model-iter-buckling-'+str(iter)].parts['Part-1'].deleteElement(elements = mddb.models['Model-iter-buckling-'+str(iter)].parts['Part-1'].sets['VS_FI'])
            slb_FI_2ply = []
            slb_FI_3ply = []
            slb_FI_4ply = []
            slb_FI_6ply = []
            vlb_FI = []

        a = FEA_FI(iter,mddb,xe,ae_FI, ae1, ae1_2, ae1_3, ae2, ae5)

        oh_FI.append(a[0])
        oh.append(a[1])
        oh_buck.append(a[2])
        oh_FI_1.append(a[3])
        oh_FI_2.append(a[4])
        oh_FI_3.append(a[5])
        oh_total.append(a[6])
        
        # Process sensitivities
        if rmin > 0: fltAe_FI(ae_FI,fm)
        if iter > 0: ae_FI=dict([(k,(ae_FI[k]+oae_FI[k])/2.0) for k in ae_FI.keys()])
        oae_FI = ae_FI.copy()
        # BESO optimization

        vh.append(sum(xe.values())/Element_Totalnumber_initial)
        
        
        if not executed and oh_FI[-1] < 1.0: 
            vf = vh[-1]
            executed = True  # 设置标志为True，表示已经执行过
        
        nv = max(vf,vh[-1]*(1.0-ert))
        
        BESO_FI(nv,xe,ae_FI,part,part2, elmts, c0, c1)   
        if iter>7: change = math.fabs((sum(oh_total[iter-0:iter+1])-sum(oh_total[iter-1:iter-0]))/sum(oh_total[iter-1:iter-0]))
    # Save results
mddb.customData.History = {'vol':vh,'obj':oh,'FI':oh_FI,'obj_buck':oh_buck,'FI1':oh_FI_1,'FI2':oh_FI_2,'FI3':oh_FI_3,'Total':oh_total}
mddb.saveAs('Final_design.cae')