#! /user/bin/python
#-*-coding: UTF-8-*-
# -*- coding: mbcs -*-
# Do not delete the following import lines
from abaqus import *
from abaqusConstants import *
import __main__
from part import *
from material import *
from section import *
from assembly import *
from step import *
from interaction import *
from load import *
from mesh import *
from optimization import *
from job import *
from sketch import *
from visualization import *
from connectorBehavior import *
from odbAccess import*
from textRepr import prettyPrint
from numpy import linalg
import time
from os.path import exists
import math,customKernel
from abaqus import getInput,getInputs
from odbAccess import openOdb
import xyPlot
import regionToolset
import displayGroupOdbToolset as dgo
import displayGroupMdbToolset as dgm
import sys, os, glob
import numpy as np
import numpy
## Function of preparing filter map (Fm = {elm1:[[el1,el2,...],[wf1,wf2,...]],...}) (NumPy) improve speed
def preFlt(Rmin,Elmts,Nds,Fm):
    import numpy as np
    # Calculate element centre coordinates
    elm, c0 = np.zeros(len(Elmts)), np.zeros((len(Elmts),3))
    for i in range(len(elm)):
        elm[i] = Elmts[i].label
        nds = Elmts[i].connectivity
        for nd in nds: c0[i] = np.add(c0[i],np.divide(Nds[nd].coordinates,len(nds)))
    # Weighting factors
    for i in range(len(elm)):
        Fm[elm[i]] = [[],[]]
        for j in range(len(elm)):
            dis = np.square(np.sum(np.power(np.subtract(c0[i],c0[j]),2)))
            if dis<Rmin: 
                Fm[elm[i]][0].append(elm[j])
                Fm[elm[i]][1].append(Rmin - dis)
        Fm[elm[i]][1] = np.divide(Fm[elm[i]][1],np.sum(Fm[elm[i]][1]))